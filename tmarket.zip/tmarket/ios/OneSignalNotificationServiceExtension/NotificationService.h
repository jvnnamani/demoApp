//
//  NotificationService.h
//  OneSignalNotificationServiceExtension
//
//  Created by Dhiman Seal on 09/07/21.
//

#import <UserNotifications/UserNotifications.h>

@interface NotificationService : UNNotificationServiceExtension

@end
