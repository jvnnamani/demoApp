package com.dhi13man.flip_everest

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
